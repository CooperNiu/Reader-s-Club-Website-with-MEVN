// import Vue from 'vue'
import { normalRouter } from '@/router/router'
const normal = {
    state: {
        routers: normalRouter
    },
    mutations: {

    }
    
}
export default normal