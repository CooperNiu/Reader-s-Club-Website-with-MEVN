// import Vue from 'vue'
import {adminRouter} from '@/router/router'
const admin = {
    state: {
        routers: adminRouter
    },
    mutations: {

    }
    
}
export default admin