<template>
  <div>
    <Row :gutter="10">
      <Col :xs="12" :sm="12" :md="8">
        <router-link :to="{name: 'adminUserList'}">
          <info-card
            info-text="用户数"
            id-name="user_num"
            color="#2d8cf0"
            icon-type="ios-people"
            :end-val="count.userNum"></info-card>
        </router-link>

      </Col>
      <Col :xs="12" :sm="12" :md="8">
        <router-link :to="{name: 'adminPageList'}">
          <info-card
            info-text="文章数"
            id-name="page_num"
            color="#64d572"
            icon-type="ios-paper"
            :end-val="count.pageNum"></info-card>
        </router-link>

      </Col>
      <Col :xs="12" :sm="12" :md="8">
        <router-link :to="{name: 'adminCommentList'}">
          <info-card
            info-text="留言数"
            id-name="comment_num"
            color="#999"
            icon-type="ios-photos"
            :end-val="count.commentNum"></info-card>
        </router-link>
      </Col>
      <Col :xs="12" :sm="12" :md="8">
        <router-link :to="{name: 'adminTagList'}">
          <info-card
            info-text="标签数"
            id-name="tag_num"
            color="#C8C8C8"
            icon-type="ios-radio"
            :end-val="count.tagNum"></info-card>
        </router-link>
      </Col>
    </Row>
  </div>
</template>
<script>
  import infoCard from './components/infoCard'

  export default {
    components: {
      infoCard,
    },
    data() {
      return {
        count: {
          userNum: 0,
          pageNum: 0,
          commentNUm: 0,
          tagNum:0
        }
      }
    },
    mounted() {
      this.initPage()
    },
    methods: {
      initPage() {
        this.Common.axios('/api/statistics').then(res => {
          this.count = res.data.data
        })
      }
    }
  }
</script>
