<template>
  <div class="main-content">
    <Table :columns="columns" :data="list"></Table>
  </div>
</template>
<script>
  export default {
    name: 'tagList',
    data() {
      return {
        columns: [
          {
            title: 'id',
            key: '_id'
          },
          {
            title: '标签名',
            key: 'name'
          },
          {
            title: '关联文章数',
            key: 'page_num'
          },
          {
            title: '操作',
            render: (h, params) => {
              return h('Button', {
                props: {
                  type: 'error',
                  size: 'small'
                },
                on: {
                  click: () => {
                    this.deleteTag(params.row)
                  }
                }
              }, '删除标签')
            }
          }
        ],
        list: []
      }
    },
    mounted() {
      this.getTaglist()
    },
    methods: {
      getTaglist() {
        this.Common.axios('/api/tag/taglist').then(res => {
          this.list = res.data.data.result
        })
      },
      deleteTag(tag) {
        var id = tag._id
        this.Common.axios('/api/tag/delete', id).then(res => {
          this.$Message.success('标签删除成功')
          this.getTaglist()
        })
      },
    }
  }
</script>
<style scoped>
</style>
