<template>
  <div class="main-content">
    <div>
      <Table :columns="comment_column" :data="comment_list"></Table>
    </div>
    <div style="margin-top: 20px">
      <Page :total="total" show-sizer @on-change="pageChange" @on-page-size-change="pageSizeChange"></Page>
    </div>

  </div>
</template>
<script>
  import {Common} from '@/assets/js/common'

  export default {
    name: 'commentlist',
    data() {
      return {
        comment_column: [
          {
            title: 'id',
            key: '_id'
          },
          {
            title: '用户名',
            key: 'create_user'
          },
          {
            title: '留言',
            key: 'content'
          },
          {
            title: '回复留言',
            key: 'reply_content'
          },
          // {
          //     title: '介绍',
          //     key: 'bio'
          // },
          {
            title: '操作',
            render: (h, params) => {
              return h('Button', {
                props: {
                  type: 'error',
                  size: 'small'
                },
                on: {
                  click: () => {
                    this.deleteComment(params.row._id)
                  }
                }
              }, '删除留言')
            }
          }
        ],
        comment_list: [],
      }
    },
    mounted() {
      this.getAllComment()
    },
    methods: {
      getAllComment(pageSize = '10', page = '1') { // 获取用户列表
        this.Common.axios('/api/comment/list', {pageSize, page}).then(res => {
          this.comment_list = res.data.data.result
          this.total = res.data.data.total_num
        })
      },
      pageChange(page) {
        this.page = page
        this.getAllComment(this.page_size, this.page)
      },
      pageSizeChange(pageSize) {
        this.page_size = pageSize
        this.getAllComment(this.page_size, this.page)
      },
      deleteComment(_id) {
        this.Common.axios('/api/comment/deletecomment', _id).then(res => {
          this.$Message.success('留言删除成功')
          this.getAllComment(this.page_size, this.page)
        })
      }
    }
  }
</script>
<style scoped>
</style>
