<template>
  <div>
    <Timeline>
      <TimelineItem color="#aaaaaa">
        <!-- <div slot="dot" :style="{width:'13px',height:'13px',borderRadius:'50%',background:'#555',position:'absolute', border:'1px solid transparent'}"></div> -->
        <span>目前共计 {{total}} 篇文章。</span>
      </TimelineItem>
      <template v-for="(year, i) in pageList">
        <TimelineItem color="#aaa" :key="i+'a'">
          <span class="year">{{year.year}}</span>
        </TimelineItem>
        <TimelineItem color="#aaa" v-for="(page,j) in year.pagelist" :key="j+'b'+i">
          <router-link :to="{name: 'pageDetail', params: {id: page._id}}">
            <div class="content">
              <span class="time">{{ page.create_time.substring(5,10) }}</span>
              <span class="draft-title">{{ page.title }}</span>
              <template v-if="page.secret">
                <span :style="{fontSize: '16px'}">|</span>
                <Badge text="私密" :offset="[-5, -20]">
                    <a href="#" class="demo-badge"></a>
                </Badge>
              </template>
            </div>
          </router-link>
        </TimelineItem>
      </template>

    </Timeline>
    <div class="pagination" style="margin-bottom: 20px;">
      <new-page :total="total" v-if="pageSize<total" @on-change="pageChange"></new-page>
    </div>
  </div>
</template>
<script>
// import page from './components/page'
export default {
  components: {
    // page
  },
  data() {
    return {
      pageList: [],
      pageSize: 10,
      page: 1,
      total: 0,
      username: this.Cookies.get('user')
    }
  },
  mounted() {
    this.getPageList()
  },
  methods: {
    getPageList() {
      const post_data = {
        type: 'create_user',
        status: 'normal',
        content: this.username,
        pageSize: this.pageSize,
        page: this.page
      }
      this.Common.axios('/api/page/limitpagelist', post_data).then(res => {
        this.pageList = this.seperateByYear(res.data.data.result)
        this.total = res.data.data.total
      })
    },
    seperateByYear(pagelist) {
      // 将文章按照创建年份分类
      let year_arr = []
      pagelist.forEach(page => {
        let year = page.create_time.substring(0, 4)
        if (!year_arr.includes(year)) {
          year_arr.push(year)
        }
      })
      return year_arr.map(year => {
        let single = {}
        single.year = year
        single.pagelist = pagelist.filter(
          page => page.create_time.substring(0, 4) === year
        )
        return single
      })
    },
    pageChange (page) {
      this.page = page
      this.getPageList()
    },
  }
}
</script>
<style lang="scss" scoped>
.year {
  font-size: 22px;
  color: #555;
}
.content {
  color: #666;
  padding: 0 0 10px;
  border-bottom: 1px dashed #cccccc;
  &:hover {
    border-color: #666;
  }
  .time {
    font-size: 12px;
  }

  .draft-title {
    // padding-right: 5px;
    padding-left: 5px;
    width: auto;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    font-size: 16px;
  }
}
</style>
