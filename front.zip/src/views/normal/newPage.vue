<template>
  <div id="editor">
    <el-form ref="pageForm" :rules="rule" :model="pageObject">
      <el-form-item prop="title">
        <el-input placeholder="标题" v-model="pageObject.title"></el-input>
      </el-form-item>
      <el-form-item prop="tags">
        <el-select placehoder="标签" ref="tagSelect" v-model="pageObject.tags" :multiple="true" :filterable="true"
                   allow-create style="width: 100%" @change="selectChange">
          <el-option v-for="(name, index) in tagList" :value="name" :key="index"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="content">
        <mavon-editor v-model="pageObject.content" ></mavon-editor>
      </el-form-item>
      <el-form-item label="是否私密">
        <el-switch v-model="pageObject.secret">
        </el-switch>
      </el-form-item>
      <el-form-item>
        <el-button @click="save('draft')">保存草稿</el-button>
        <el-button type="primary" @click="save('normal')" v-if="user.username === 'admin'">发布</el-button>
      </el-form-item>
    </el-form>
    <Modal v-model="tagModal" title="创建标签">
    <Form ref="tagForm" :model="tag_obj" :rules="tagRule">
      <FormItem prop="name">
        <Input v-model="tag_obj.name"></Input>
      </FormItem>
      <!--        <FormItem prop="description">-->
      <!--          <Input v-model="tag_obj.description" type="textarea" placeholder="输入对标签的描述"></Input>-->
      <!--        </FormItem>-->
    </Form>
    <div slot="footer">
      <Button @click="tagModal = false">取消</Button>
      <Button type="primary" @click="createTagSubmit">确定</Button>
    </div>
  </Modal>
  </div>

</template>

<script>
  // Local Registration
  import {mavonEditor} from 'mavon-editor'
  import 'mavon-editor/dist/css/index.css'

  export default {
    name: 'editor',
    components: {
      mavonEditor
      // or 'mavon-editor': mavonEditor
    },
    data() {
      return {
        user: JSON.parse(localStorage.getItem('user')),
        id: this.$route.params.id,
        tagList: [],
        tagModal: false,
        tag_obj: {
          name: '',
          description: ''
        },
        tagRule: {
          name: [
            {
              required: true,
              trigger: 'change'
            }
          ],
          description: [
            {
              required: false,
              trigger: 'change'
            }
          ]
        },
        pageObject: {
          title: '',
          tags: [],
          // content: '### 用 markdown 写一篇文章\n ',
          content: '@[TOC](这里写自定义目录标题)\n' +
            '\n' +
            '# 欢迎使用Markdown编辑器\n' +
            '\n' +
            '你好！ 这是你第一次使用 **Markdown编辑器** 所展示的欢迎页。如果你想学习如何使用Markdown编辑器, 可以仔细阅读这篇文章，了解一下Markdown的基本语法知识。\n' +
            '\n' +
            '## 新的改变\n' +
            '\n' +
            '我们对Markdown编辑器进行了一些功能拓展与语法支持，除了标准的Markdown编辑器功能，我们增加了如下几点新功能，帮助你用它写博客：\n' +
            '\n' +
            ' 1. **全新的界面设计** ，将会带来全新的写作体验；\n' +
            ' 2. 在创作中心设置你喜爱的代码高亮样式，Markdown **将代码片显示选择的高亮样式** 进行展示；\n' +
            ' 3. 增加了 **图片拖拽** 功能，你可以将本地的图片直接拖拽到编辑区域直接展示；\n' +
            ' 4. 全新的 **KaTeX数学公式** 语法；\n' +
            ' 5. 增加了支持**甘特图的mermaid语法[^1]** 功能；\n' +
            ' 6. 增加了 **多屏幕编辑** Markdown文章功能；\n' +
            ' 7. 增加了 **焦点写作模式、预览模式、简洁写作模式、左右区域同步滚轮设置** 等功能，功能按钮位于编辑区域与预览区域中间；\n' +
            ' 8. 增加了 **检查列表** 功能。\n' +
            ' [^1]: [mermaid语法说明](https://mermaidjs.github.io/)\n' +
            '\n' +
            '## 功能快捷键\n' +
            '\n' +
            '撤销：<kbd>Ctrl/Command</kbd> + <kbd>Z</kbd>\n' +
            '重做：<kbd>Ctrl/Command</kbd> + <kbd>Y</kbd>\n' +
            '加粗：<kbd>Ctrl/Command</kbd> + <kbd>B</kbd>\n' +
            '斜体：<kbd>Ctrl/Command</kbd> + <kbd>I</kbd>\n' +
            '标题：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>H</kbd>\n' +
            '无序列表：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>U</kbd>\n' +
            '有序列表：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>O</kbd>\n' +
            '检查列表：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>C</kbd>\n' +
            '插入代码：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>K</kbd>\n' +
            '插入链接：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>L</kbd>\n' +
            '插入图片：<kbd>Ctrl/Command</kbd> + <kbd>Shift</kbd> + <kbd>G</kbd>\n' +
            '\n' +
            '\n' +
            '## 合理的创建标题，有助于目录的生成\n' +
            '\n' +
            '直接输入1次<kbd>#</kbd>，并按下<kbd>space</kbd>后，将生成1级标题。\n' +
            '输入2次<kbd>#</kbd>，并按下<kbd>space</kbd>后，将生成2级标题。\n' +
            '以此类推，我们支持6级标题。有助于使用`TOC`语法后生成一个完美的目录。\n' +
            '\n' +
            '\n' +
            '\n' +
            '## 如何改变文本的样式\n' +
            '\n' +
            '*强调文本* _强调文本_\n' +
            '\n' +
            '**加粗文本** __加粗文本__\n' +
            '\n' +
            '==标记文本==\n' +
            '\n' +
            '~~删除文本~~\n' +
            '\n' +
            '> 引用文本\n' +
            '\n' +
            'H~2~O is是液体。\n' +
            '\n' +
            '2^10^ 运算结果是 1024.\n' +
            '\n' +
            '\n' +
            '\n' +
            '## 插入链接与图片\n' +
            '\n' +
            '链接: [新建文章](http://localhost:7000/new).\n' +
            '\n' +
            '图片：![icon.jpg](https://avatar.csdn.net/7/7/B/1_ralf_hx163com.jpg)\n' +
            '\n' +
            '## 如何插入一段漂亮的代码片\n' +
            '\n' +
            '```javascript\n' +
            '// An highlighted block\n' +
            'var foo = \'bar\';\n' +
            '```\n' +
            '\n' +
            '\n' +
            '## 生成一个适合你的列表\n' +
            '\n' +
            '- 项目\n' +
            '  - 项目\n' +
            '    - 项目\n' +
            '\n' +
            '1. 项目1\n' +
            '2. 项目2\n' +
            '3. 项目3\n' +
            '\n' +
            '- [ ] 计划任务\n' +
            '- [x] 完成任务\n' +
            '\n' +
            '\n' +
            '## 创建一个表格\n' +
            '一个简单的表格是这么创建的：\n' +
            '项目     | Value\n' +
            '-------- | -----\n' +
            '电脑  | $1600\n' +
            '手机  | $12\n' +
            '导管  | $1\n' +
            '\n' +
            '### 设定内容居中、居左、居右\n' +
            '使用`::: hljs-center`:\n' +
            '::: hljs-center\n' +
            '居中\n' +
            ':::\n' +
            '使用`::: hljs-left`:\n' +
            '::: hljs-left\n' +
            '居左\n' +
            ':::\n' +
            '使用`::: hljs-right`:\n' +
            '::: hljs-right\n' +
            '居右\n' +
            ':::\n' +
            '### 如何插入表格\n' +
            '| 第一列       | 第二列         | 第三列        |\n' +
            '|:-----------:| -------------:|:-------------|\n' +
            '| 第一列文本居中 | 第二列文本居右  | 第三列文本居左 | \n' +
            '\n' +
            '\n' +
            '### SmartyPants\n' +
            'SmartyPants将ASCII标点字符转换为“智能”印刷标点HTML实体。例如：\n' +
            '|    TYPE   |ASCII                          |HTML                         \n' +
            '|----------------|-------------------------------|-----------------------------|\n' +
            '|Single backticks|`\'Isn\'t this fun?\'`            |\'Isn\'t this fun?\'            |\n' +
            '|Quotes          |`"Isn\'t this fun?"`            |"Isn\'t this fun?"            |\n' +
            '|Dashes          |`-- is en-dash, --- is em-dash`|-- is en-dash, --- is em-dash|\n' +
            '\n' +
            '\n' +
            '## 创建一个自定义列表\n' +
            'Markdown\n' +
            ':  Text-to-HTML conversion tool\n' +
            '\n' +
            'Authors\n' +
            ':  John\n' +
            ':  Luke\n' +
            '\n' +
            '\n' +
            '## 如何创建一个注脚\n' +
            '\n' +
            '一个具有注脚的文本。[^2]\n' +
            '\n' +
            '[^2]: 注脚的解释\n' +
            '\n' +
            '\n' +
            '##  注释也是必不可少的\n' +
            '\n' +
            'Markdown将文本转换为 HTML。\n' +
            '\n' +
            '*[HTML]:   超文本标记语言\n' +
            '\n' +
            '\n' +
            '## KaTeX数学公式\n' +
            '\n' +
            '您可以使用渲染LaTeX数学表达式 [KaTeX](https://khan.github.io/KaTeX/):\n' +
            '\n' +
            'Gamma公式展示 $\\Gamma(n) = (n-1)!\\quad\\forall\n' +
            'n\\in\\mathbb N$ 是通过欧拉积分\n' +
            '\n' +
            '$$\n' +
            '\\Gamma(z) = \\int_0^\\infty t^{z-1}e^{-t}dt\\,.\n' +
            '$$\n' +
            '\n' +
            '> 你可以找到更多关于的信息 **LaTeX** 数学表达式[here][1].\n' +
            '\n' +
            ' [1]: http://meta.math.stackexchange.com/questions/5020/mathjax-basic-tutorial-and-quick-reference\n' +
            ' [2]: https://mermaidjs.github.io/\n' +
            ' [3]: https://mermaidjs.github.io/\n' +
            ' [4]: http://adrai.github.io/flowchart.js/',
          status: '',
          secret: false
        },
        rule: {
          title: [
            {
              required: true,
              type: 'string',
              message: '请输入文章标题'
            }
          ],
          tags: [
            {
              required: true,
              type: 'array',
              message: '请选择标签'
            }
          ],
          content: [
            {
              required: true,
              type: 'string',
              message: '请输入文章内容'
            }
          ]
        }
      }
    },
    async mounted() {
      await this.getAllTags()
      this.getPageDetail()
    },
    beforeRouteLeave(to, from, next) {
      if (this.pageObject.title || this.pageObject.tags.length) {
        this.$Modal.confirm({
          title: '提示',
          content: '<p>你有未保存的文章，确定要离开吗？</p>',
          okText: '离开',
          cancelText: '取消',
          onOk: () => {
            next()
          }
        });
      } else {
        next()
      }
    },
    methods: {
      getAllTags() {
        return this.Common.axios('/api/tag/alltags').then(res => {
          this.tagList = res.data.data
        })
      },
      selectChange(arr) {
        // 判断是否新增 tag
        let last_tag = arr.pop()
        if (this.tagList.includes(last_tag)) {
          arr.push(last_tag)
        } else {
          setTimeout(() => {
            this.$refs['tagSelect'].blur()
            this.tag_obj.name = last_tag
            this.tagModal = true
          }, 30)
        }
      },
      getPageDetail() {
        if (this.id) {
          this.Common.axios('/api/page/detail', {id: this.id}).then(res => {
            this.$set(this, 'pageObject', res.data.data)
            if (typeof (this.pageObject.secret) === 'undefined') {
              this.$set(this.pageObject, 'secret', false)
            }
          })
        } else {
          return false
        }
      },
      createTagSubmit() {
        this.$refs['tagForm'].validate(valid => {
          if (valid) {
            this.Common.axios('/api/tag/create', this.tag_obj).then(async (res) => {
              this.tagModal = false
              await this.getAllTags()
              this.pageObject.tags.push(this.tag_obj.name)
              this.$refs['tagForm'].resetFields()
            })
          }
        })
      },

      save(type) {
        this.$refs['pageForm'].validate(valid => {
          if (valid) {
            this.pageObject.status = type
            let url = ''
            if (this.id) {
              url = '/api/page/edit'
              this.pageObject.id = this.id
            } else {
              url = '/api/page/new'
            }
            this.Common.axios(url, this.pageObject).then(res => {
              this.$Message.success('提交成功')
              this.$store.commit('updateUserInfo', res.data.data)
              this.$refs['pageForm'].resetFields()
              if (type === 'normal' && this.id) {
                this.$router.push({name: 'pageDetail', params: {id: this.id}})
              } else if (type === 'normal' && !this.id) {
                this.$router.push({name: 'normalPageList'})
              } else {
                this.$router.push({name: 'normalMyDraftList'})
              }
            })
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  #editor {
    /*margin: auto;*/
    width: 80%;
    /*height: 500px;*/
  }

  .ivu-form-item {
    margin-bottom: 18px;
  }
</style>












<!--<template>-->
<!--<div>-->
<!--    <el-form ref="pageForm" :rules="rule" :model="pageObject">-->
<!--        <el-form-item prop="title">-->
<!--            <el-input placeholder="标题" v-model="pageObject.title"></el-input>-->
<!--        </el-form-item>-->
<!--        <el-form-item prop="tags">-->
<!--            <el-select placehoder="标签" ref="tagSelect" v-model="pageObject.tags" :multiple="true" :filterable="true" allow-create style="width: 100%" @change="selectChange">-->
<!--                <el-option v-for="(name, index) in tagList" :value="name" :key="index"></el-option>-->
<!--            </el-select>-->
<!--        </el-form-item>-->
<!--        <el-form-item prop="content">-->
<!--            <markdown-editor v-model="pageObject.content"></markdown-editor>-->
<!--        </el-form-item>-->
<!--        <el-form-item label="是否私密">-->
<!--            <el-switch v-model="pageObject.secret">-->
<!--            </el-switch>-->
<!--        </el-form-item>-->
<!--        <el-form-item>-->
<!--            <el-button @click="save('draft')">保存草稿</el-button>-->
<!--            <el-button type="primary" @click="save('normal')" v-if = "user.username === 'admin'">发布</el-button>-->
<!--        </el-form-item>-->
<!--    </el-form>-->
<!--    <Modal v-model="tagModal" title="创建标签">-->
<!--        <Form ref="tagForm" :model="tag_obj" :rules="tagRule" >-->
<!--        <FormItem prop="name">-->
<!--            <Input v-model="tag_obj.name"></Input>-->
<!--        </FormItem>-->
<!--        <FormItem prop="description">-->
<!--            <Input v-model="tag_obj.description" type="textarea" placeholder="输入对标签的描述"></Input>-->
<!--        </FormItem>-->
<!--        </Form>-->
<!--        <div slot="footer">-->
<!--        <Button @click="tagModal = false">取消</Button>-->
<!--        <Button type="primary" @click="createTagSubmit">确定</Button>-->
<!--        </div>-->
<!--    </Modal>-->
<!--</div>-->

<!--</template>-->

<!--<script>-->
<!--import mEditor from 'simple-m-editor'-->
<!--export default {-->
<!--    components: {-->
<!--        markdownEditor: mEditor-->
<!--    },-->
<!--    data () {-->
<!--        return {-->
<!--            user: JSON.parse(localStorage.getItem('user')),-->
<!--            id: this.$route.params.id,-->
<!--            tagList: [],-->
<!--            tagModal: false,-->
<!--            tag_obj: {-->
<!--                name: '',-->
<!--                description: ''-->
<!--            },-->
<!--            tagRule: {-->
<!--                name: [-->
<!--                {-->
<!--                    required: true,-->
<!--                    trigger: 'change'-->
<!--                }-->
<!--                ],-->
<!--                description: [-->
<!--                {-->
<!--                    required: true,-->
<!--                    trigger: 'change'-->
<!--                }-->
<!--                ]-->
<!--            },-->
<!--            pageObject: {-->
<!--                title: '',-->
<!--                tags: [],-->
<!--                content: '### 用 markdown 写一篇文章',-->
<!--                status: '',-->
<!--                secret: false-->
<!--            },-->
<!--            rule: {-->
<!--                title: [-->
<!--                    {-->
<!--                        required: true,-->
<!--                        type: 'string',-->
<!--                        message: '请输入文章标题'-->
<!--                    }-->
<!--                ],-->
<!--                tags: [-->
<!--                    {-->
<!--                        required: true,-->
<!--                        type: 'array',-->
<!--                        message: '请选择标签'-->
<!--                    }-->
<!--                ],-->
<!--                content: [-->
<!--                    {-->
<!--                        required: true,-->
<!--                        type: 'string',-->
<!--                        message: '请输入文章内容'-->
<!--                    }-->
<!--                ]-->
<!--            }-->
<!--        }-->
<!--    },-->
<!--    async mounted () {-->
<!--        await this.getAllTags()-->
<!--        this.getPageDetail()-->
<!--    },-->
<!--    beforeRouteLeave (to, from, next) {-->
<!--        if (this.pageObject.title || this.pageObject.tags.length) {-->
<!--            this.$Modal.confirm({-->
<!--                title: '提示',-->
<!--                content: '<p>你有未保存的文章，确定要离开吗？</p>',-->
<!--                okText: '离开',-->
<!--                cancelText	: '取消',-->
<!--                onOk: () => {-->
<!--                    next()-->
<!--                }-->
<!--            });-->
<!--        } else {-->
<!--            next()-->
<!--        }-->
<!--    },-->
<!--    methods: {-->
<!--        getAllTags () {-->
<!--            return this.Common.axios('/api/tag/alltags').then(res => {-->
<!--                this.tagList = res.data.data-->
<!--            })-->
<!--        },-->
<!--        selectChange (arr) {-->
<!--            // 判断是否新增 tag-->
<!--            let last_tag = arr.pop()-->
<!--            if (this.tagList.includes(last_tag)) {-->
<!--                arr.push(last_tag)-->
<!--            } else {-->
<!--                setTimeout(() => {-->
<!--                    this.$refs['tagSelect'].blur()-->
<!--                    this.tag_obj.name = last_tag-->
<!--                    this.tagModal = true-->
<!--                }, 30)-->
<!--            }-->
<!--        },-->
<!--        getPageDetail () {-->
<!--            if (this.id) {-->
<!--                this.Common.axios('/api/page/detail', { id: this.id }).then(res => {-->
<!--                    this.$set(this, 'pageObject', res.data.data)-->
<!--                    if (typeof(this.pageObject.secret)==='undefined') {-->
<!--                        this.$set(this.pageObject, 'secret', false)-->
<!--                    }-->
<!--                })-->
<!--            } else {-->
<!--                return false-->
<!--            }-->
<!--        },-->
<!--        createTagSubmit () {-->
<!--            this.$refs['tagForm'].validate(valid => {-->
<!--                if (valid) {-->
<!--                this.Common.axios('/api/tag/create', this.tag_obj).then(async (res) => {-->
<!--                    this.tagModal = false-->
<!--                    await this.getAllTags()-->
<!--                    this.pageObject.tags.push(this.tag_obj.name)-->
<!--                    this.$refs['tagForm'].resetFields()-->
<!--                })-->
<!--                }-->
<!--            })-->
<!--        },-->

<!--        save (type) {-->
<!--            this.$refs['pageForm'].validate(valid => {-->
<!--                if (valid) {-->
<!--                    this.pageObject.status = type-->
<!--                    let url = ''-->
<!--                    if (this.id) {-->
<!--                        url = '/api/page/edit'-->
<!--                        this.pageObject.id = this.id-->
<!--                    } else {-->
<!--                        url = '/api/page/new'-->
<!--                    }-->
<!--                    this.Common.axios(url, this.pageObject).then(res => {-->
<!--                        this.$Message.success('提交成功')-->
<!--                        this.$store.commit('updateUserInfo', res.data.data)-->
<!--                        this.$refs['pageForm'].resetFields()-->
<!--                        if (type === 'normal' && this.id) {-->
<!--                            this.$router.push({ name: 'pageDetail', params: { id: this.id } })-->
<!--                        } else if (type === 'normal' && !this.id) {-->
<!--                            this.$router.push({ name: 'normalPageList' })-->
<!--                        } else {-->
<!--                            this.$router.push({ name: 'normalMyDraftList' })-->
<!--                        }-->
<!--                    })-->
<!--                }-->
<!--            })-->
<!--        }-->
<!--    }-->
<!--}-->
<!--</script>-->

<!--<style lang="scss" scoped>-->
<!--    .ivu-form-item {-->
<!--        margin-bottom: 18px;-->
<!--    }-->
<!--</style>-->
