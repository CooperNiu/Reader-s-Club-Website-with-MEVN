<template>
  <div>
    <p>Created By CooperNiu <a class="github-link" href="https://github.com/CooperNiu">
      <Icon type="logo-github" :size="20"></Icon>
    </a></p>

  </div>
</template>

<style lang="scss" scoped>
  p {
    margin-top: 5px;
  }

  .github-link {
    color: #495060;

    &:hover {
      color: #000;
    }
  }

  .footer-link {
    border-bottom: 1px solid rgb(153, 153, 153);
    color: #495060;

    &:hover {
      color: #000;
      border-bottom-color: #000;
    }
  }
</style>
