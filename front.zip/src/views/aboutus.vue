<!--TODO 优化该页面,添加二维码-->
<template>
  <div >
      <div class="content-title-big">
        思辨读书会
      </div><br>
    <div class="intro">
      是由海内外的大学生和社会上的一些爱好读书的书友们共同筹建的。
    </div>
    <div class="intro">
    </div>
    <div class="intro">是非营利组织，成立于2016年10月。
    </div>
    <div class="intro">
    </div>
    <div class="intro">坚持每周分享一本好书，目前已举办100多期线上活动与3期线下讲座。
    </div>
    <div class="intro">
    </div>
    <div class="intro">目标是分享有价值的思想，让思考更自由，精神更独立。
    </div>
    <div class="intro">
    </div>
    <div class="intro">宗旨是集众智，挑好书，留精华内容，创优质社群。
    </div><br>
    <label class="content-title">扫一扫下面的二维码加入我们吧</label>
  <br><br>
    <img src="../../static/bicode.jpg" width="333" >
  </div>
</template>
<script>
  import blogHeader from "./normal/components/Header";
  import blogFooter from "./normal/components/Footer";
  import siderUserInfo from "./normal/components/siderUserInfo";

  export default {
    components: {
      blogHeader,
      blogFooter,
      siderUserInfo
    },
    data() {
      return {
        isCollapsed: true,
        socket: io(`${process.env.NODE_ENV === 'development' ? 'http://localhost:8082' : 'https://hellomrbigbigshot.xyz'}`),
        unreadMsgNum: 0
      };
    },
    async created() {
      await this.getUserInfo();
      this.isCollapsed = this.user ? false : true;
      if (this.user) {
        this.Cookies.set("user", this.user, {expires: 7});
      }
      this.socket.on("unread-comment", msg => {
        if (msg > 0 && msg !== this.unreadMsgNum && this.$route.name !== 'normalGuestBook') {
          this.unreadMsgNum = msg
          this.$Notice.destroy()
          this.$Notice.info({
            title: '提示',
            render: h => {
              return h('div', [
                h('span', '你有'),
                h('a', {
                  on: {
                    click: () => {
                      this.$router.push({name: 'normalGuestBook'})
                    }
                  }
                }, `${msg}`),
                h('span', '条未读信息')
              ])
            },
            duration: 0
          })
        }
      })
    },
    computed: {
      rotateIcon() {
        return ["menu-icon", this.isCollapsed ? "rotate-icon" : ""];
      },
      menuitemClasses() {
        return ["page-sider", this.isCollapsed ? "collapsed-menu" : ""];
      },
      user() {
        return this.Cookies.get("user") || this.$route.query.username || "" || this.Cookies.get("usertype");
      }
    },
    methods: {
      getUserInfo() {
        if (this.user) {
          return this.Common.axios("/api/signin/getUserInfo", {
            username: this.user
          }).then(res => {
            let result = res.data.data;
            localStorage.setItem("user", JSON.stringify(result));
            this.$store.commit("updateUserName", this.user);
            this.$store.commit("updateUserInfo", {
              page_num: result.page_num,
              draft_num: result.draft_num,
              comment_num: result.comment_num,
              avatar: result.avatar
            });
          });
        }
      },
      collapsedSider() {
        // 侧边栏显示切换
        this.$refs.pageSider.toggleCollapse();
      },
      handleRouter(name) {
        // 路由跳转
        this.$router.push({name: name});
      }
    }
  };
</script>
<style lang="scss" scoped>
  .icon-wrapper {
    width: 25px;
    position: fixed;
    z-index: 111;
    right: 50px;
    bottom: 20px;

    .single-icon-wrapper {
      width: 25px;
      height: 25px;
      text-align: center;
      background: #222222;
      margin-top: 5px;
      cursor: pointer;

      .rotateIcon {
        transform: rotate(-90deg);
      }
    }
  }

  .page-sider {
    background: #222;
    height: 100vh;
    width: 320px;
    position: fixed;
    overflow: auto;
  }

  .collapsed-menu {
    width: 0 !important;
    min-width: 0 !important;
    max-width: 0 !important;
    transition: width 5s ease 5s;
  }

  .menu-icon {
    transition: all 0.3s;
  }

  .rotate-icon {
    transform: rotate(-90deg);
  }

  .pagination {
    margin: 120px 0;
  }
  .content-title-big{
    /*font-weight: 400;*/
    font-size: 36px;
    /*margin-bottom: 20px;*/
    /*width: auto;*/
    /*color: #000000;*/

    /*border-bottom: 2px solid #fff;*/
    /*position: relative;*/
  }
  .content-title {
    font-weight: 400;
    font-size: 26px;
    margin-bottom: 20px;
    width: auto;
    color: #000000;

    /*border-bottom: 2px solid #fff;*/
    position: relative;
  }

  .intro {
    /*font-family: Lato, 'PingFang SC', 'Microsoft YaHei', sans-serif;*/
    line-height: 2;
    font-size: 12px;
  }

  .main-footer {
    margin: 0 auto;
    padding-left: 0px !important;
  }

  @media (max-width: 991px) {
    .home-sider,
    .icon-wrapper {
      display: none;
    }
  }

  @media (max-width: 767px) {
    .main-content,
    .main-footer {
      margin: 20px 20px;
      width: auto;
    }
  }

  @media (max-width: 1600px) {
    .main-content,
    .main-footer {
      width: 85%;
      max-width: 700px;
    }
  }

  @media (min-width: 1600px) {
    .main-content,
    .main-footer {
      // margin: 20px 20px;
      width: 900px;
    }
  }
</style>
