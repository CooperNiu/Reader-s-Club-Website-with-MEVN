
<template>
  <div>
      
  </div>
</template>
<script>
import {Common} from '@/assets/js/common'
export default {
    data () {
        return {

        }
    }
}
</script>