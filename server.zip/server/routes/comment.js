const express = require('express')
const router = express.Router()
const io = require('socket.io').listen('8082', {origins: '*'})
const schedule = require('node-schedule')

const CommentModel = require('../models/comment')
const ActivityModel = require('../models/activity')
const checkLogin = require('../middlewares/check').checkLogin

io.set('transports', [
    'websocket',
    'flashsocket',
    'htmlfile',
    'xhr-polling',
    'jsonp-polling',
    'polling'
])
io.set('origins', '*:*')

// 创建留言
router.post('/create', checkLogin, async (req, res, next) => {
    var content = req.body.content
    const create_user = req.body.create_user
    const page_id = req.body.page_id
    const page_title = req.body.page_title
    const to_user = req.body.to_user
    const reply_user = req.body.reply_user
    const reply_content = req.body.reply_content
    const create_time = new Date().toLocaleString()
    // var CensorWords = new Array()
    try {
        //   // 敏感词过滤
        //   var fs = require("fs");
        //
        //   // 异步读取
        //   fs.readFile('D:\\UserData\\My Documents\\GitHub\\server\\CensorWords.txt', function (err, data) {
        //     if (err) {
        //       return console.error(err);
        //     }
        //     // console.log("异步读取: " + data.toString());
        //     CensorWords = data.toString();
        //     console.log("异步读取: " + CensorWords);
        //   });
        //
        //   for (var i = 0; i < CensorWords.length; i++) {
        //     // 创建一个正则表达式
        //     var r = new RegExp(CensorWords[i], "ig");
        //
        //     content = content.replace(r, "*");
        //   }
        //   console.log(content);
        //   // 关闭文件
        //   fs.close(fd, function(err){
        //     if (err){
        //       console.log(err);
        //     }
        //     console.log("文件关闭成功");
        //   });


        const result = await CommentModel.create({
            content,
            create_user,
            page_id,
            page_title,
            to_user,
            create_time,
            reply_user,
            reply_content
        })

        // 添加一条动态
        await ActivityModel.create({
            type: 'comment',
            id: result._id,
            create_time: result.create_time,
            create_user: result.create_user,
            update_time: result.create_time
        })
        res.status(200).json({code: 'OK', data: result})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }
})

// 获取文章留言列表
router.post('/getpagecommentlist', async (req, res, next) => {
    const page_id = req.body.page_id
    try {
        let result = await CommentModel.getCommentList({type: 'page', content: page_id})
        res.status(200).json({code: 'OK', data: result})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }
})
//////////////////////////////////////////////////////////////////////////////////////////
// 获取所有用户的所有留言
router.post('/list', async (req, res, next) => {

    let pageSize = req.body.pageSize || 10
    let page = req.body.page || 1
    pageSize = typeof (pageSize) === 'number' ? pageSize : parseInt(pageSize)
    page = typeof (page) === 'number' ? page : parseInt(page)
    try {
        // CommentModel.getAllComment(pageSize, (page-1)*pageSize).then(commentlist => {
        //   let list = commentlist.map()
        // })

        let [total, result] = await Promise.all([
            CommentModel.getCommentNum(),
            CommentModel.getAllComment(pageSize, (page - 1) * pageSize)
        ])

        result = await Promise.all(result.map(async (single) => {
            single = single.toObject()
            return single
        }))
        res.status(200).json({code: 'OK', data: {result, total}})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }
    // let list = CommentModel.getAllComment()
})

///////////////////////////////////////////////////////////////////////////////////////
// 获取用户留言列表
router.post('/getusercommentlist', checkLogin, async (req, res, next) => {
    const type = req.body.type
    const create_user = req.body.create_user
    const to_user = req.body.to_user
    const username = req.session.user.username
    let pageSize = req.body.pageSize || 10
    let page = req.body.page || 1
    pageSize = typeof pageSize === 'number' ? pageSize : parseInt(pageSize)
    page = typeof page === 'number' ? page : parseInt(page)
    const Count = pageSize * (page - 1)
    const content = type === 'create_user' ? create_user : to_user
    try {
        let [result, total] = await Promise.all([
            CommentModel.getCommentList({type, content, pageSize, Count, username}),
            CommentModel.getCommentNum(type, type === 'create_user' ? create_user : to_user, username)
        ])
        res.status(200).json({code: 'OK', data: {result, total}})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }
})
// 标记留言为被删除
router.post('/deletecomment', checkLogin, async (req, res, next) => {
    const id = req.body.id
    try {
        let result = await CommentModel.deleteComment({id})
        // res.status(200).json({code: 'OK', data: '删除留言成功'})
        res.status(200).json({code: 'OK', data: result})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }
})
// 更新留言状态
router.post('/updatecommentstatus', checkLogin, async (req, res, next) => {
    const ids = req.body.ids
    try {
        if (!ids.length) {
            throw new Error('需要修改状态的留言列表不能为空')
        }
        let result = await CommentModel.updateCommentsStatus(ids)
        res.status(200).json({code: 'OK', data: '留言状态更新成功'})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }
})

// 获取未读留言数量
router.get('/getUnreadCommentNum', checkLogin, async (req, res, next) => {
    const USER = req.session.user.username
    try {
        let num = await CommentModel.getCommentNum('to_user', USER, USER, false)
        res.status(200).json({code: 'OK', data: num})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e.message})
    }

})
io.on('connect', (socket) => {
    const comment_schedule = schedule.scheduleJob('*/10 * * * * *', async () => {
        /** 一分钟查询一次是否有新的回复/留言 **/
        const USER = global.user
        if (USER !== undefined && USER !== null) { // 确认登录
            let num = await CommentModel.getCommentNum('to_user', USER, USER, false) // 获取未读的留言数量
            socket.emit('unread-comment', num)
        }
    })
})


function getCookie(str, key) {
    const REG = /([^=]+)=([^;]+);?\s*/g
    let cookie_obj = {}, result
    while ((result = REG.exec(str)) != null) {
        cookie_obj[result[1]] = result[2];
    }
    if (cookie_obj[key] === undefined) {
        return undefined
    }
    return cookie_obj[key]
}

module.exports = router
