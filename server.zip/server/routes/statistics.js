const express = require('express')
const router = express.Router()
const UserModel = require('../models/user')
const PageModel = require('../models/page')
const CommentModel = require('../models/comment')
const TagModel = require('../models/tag')
const checkLogin = require('../middlewares/check').checkLogin
// 统计数据接口
router.post('/', checkLogin, async (req, res, next) => {
    try {
        const [userNum, pageNum, commentNum, tagNum] =
            await Promise.all(
                [UserModel.getUserNum(),
                    PageModel.getPageNum({}),
                    CommentModel.getAllCommentNum(),
                    TagModel.getTagNum()
                ])
        let data = {userNum, pageNum, commentNum, tagNum}
        res.status(200).json({code: 'OK', data: data})
    } catch (e) {
        res.status(200).json({code: 'ERROR', data: e})
    }

})
module.exports = router
